<header>
	<div class="main-header">
		<div class="container-fluid">
			<div class="row align-items-center">
				<div class="col-md-2">
					<div class="side-menuBar">
						<div class="menu-Bar">
							<span></span>
							<span></span>
							<span></span>
						</div>
						<span>MORE</span>
					</div>
				</div>
				<div class="col-md-8">
					<div class="menuWrap">
						<ul class="menu">
							<li><a class="active" href="./">HOME</a></li>
							<li><a href="#">ABOUT SGL</a></li>
							<li><a href="#">EMPOWERING MINERS</a></li>
						</ul>

						<a href="./" class="logo">
							<img src="assets/images/logo1.png" alt="">
						</a>

						<ul class="menu">
							<li><a class="active" href="./">SGL REFINERY</a></li>
							<li><a href="#">NEWSROOM</a></li>
							<li><a href="#">OUR TEAM</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-2">
					<div class="header-action">
						<div class="header-search">
							<i class="far fa-search"></i>
						</div>

						<div class="header-lang">
							<span>EN</span>
						</div>

						<div class="header-btn">
							<a href="#">CONTACT US</a>
						</div>
					</div>
				</div>   
			</div>
		</div>
	</div>
</header>